from random import shuffle 
with open('td_exam.txt', encoding='utf-8') as td:
    L = [i.strip() for i in td.readlines()if i != ''][:-1]
    f = True
    while True:
        shuffle(L)
        if f:        
            for k in L:
                ent = input('Жми enter для продолжения, или пиши stop для завершения: ')
                if ent == 'stop':
                    f = False
                    break
                print('\n'*5)
                print(k)
                print('\n'*5)
        else:
            break
        