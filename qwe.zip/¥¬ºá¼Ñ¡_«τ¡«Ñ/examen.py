import random
exam = {}
t4 = {}
t5 = {}

Gruppa = [i for i in input().split()]

with open('exam.txt', encoding='utf-8') as ex:
    i = 1
    for line in ex:
        line = line.strip()
        exam[i] = line
        i += 1
    
    
with open('tasks4.txt', encoding='utf-8') as task4:
    i = 1
    for line in task4:
        line = line.strip()
        t4[i] = line
        i += 1
    
    
with open('tasks5.txt', encoding='utf-8') as task5:
    i = 1
    for line in task5:
        line = line.strip()
        t5[i] = line
        i += 1
    

n1 = [i for i in exam.keys()]
n2 = [i for i in t4.keys()]
n3 = [i for i in t5.keys()]
for s in Gruppa:
    if n1 == []:
        n1 = [i for i in exam.keys()]
    if n2 == []:
        n2 = [i for i in t4.keys()]
    if n3 == []:
        n3 = [i for i in t5.keys()]
    with open(s+'.txt','w', encoding='utf-8') as output:
        print('Теоретический вопрос:', file=output)
        ns = random.choice(n1)
        print('\t', exam[ns], end='. ', file=output)
        n1.remove(ns)
        print(file=output)
        print(file=output)
        print('Задача на 3:', file=output)
        ns = random.choice(n2)
        print('\t', t4[ns], end='', file=output)
        n2.remove(ns)
        print(file=output)
        print(file=output)
        print('Задача на 4 / 5:', file=output)
        ns = random.choice(n3)
        print('\t', t5[ns], end='', file=output)
        n3.remove(ns)







    